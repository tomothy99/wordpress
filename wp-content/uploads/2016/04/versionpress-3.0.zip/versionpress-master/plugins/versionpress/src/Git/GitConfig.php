<?php

namespace VersionPress\Git;

class GitConfig {
    public static $wpcliUserName = "WP-CLI";
    public static $wpcliUserEmail = "wpcli@localhost";
}