# VersionPress Docs

- [Dev-Setup](./Dev-Setup.md)
- [Testing](./Testing.md)