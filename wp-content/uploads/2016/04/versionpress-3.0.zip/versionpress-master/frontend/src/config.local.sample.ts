// Copy and update values from config.ts

const config = {

  api: {
    root: 'http://localhost/wordpress',
    adminUrl: 'http://localhost/wordpress/wp-admin'
  }

};

export default config;
