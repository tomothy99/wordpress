/// <reference path="tsd/tsd.d.ts" />
/// <reference path="versionpress-custom/karma-chai-sinon.d.ts" />
