Only technical issues go here; if you have trouble installing VersionPress or using it please visit https://github.com/versionpress/support first.

Good issue contains:

- Clear description
- An example / screenshot / GIF
- Info about environment, if relevant

Thanks!
